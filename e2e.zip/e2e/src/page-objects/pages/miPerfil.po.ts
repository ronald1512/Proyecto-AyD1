import { browser, by, element, ExpectedConditions } from 'protractor';

export class MiPerfilPage {

  constructor() {
  }

}
